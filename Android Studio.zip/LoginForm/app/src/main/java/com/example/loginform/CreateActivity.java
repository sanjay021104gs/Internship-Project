package com.example.loginform;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateActivity extends AppCompatActivity {
    private EditText editTextMeasurementDate, editTextMeasurementTime, editTextPartNumber,
            editTextMakingSubcontractor, editTextMakingDate,
            editTextPaintingSubcontractor, editTextPaintingDate, editTextNoOfTrays,
            editTextNoOfCoresTrays, editTextTotalCores, editTextPatternCavity,
            editTextNoOfMoldsPoured, editTextPouredCores, editTextReturnCores,
            editTextMouldingShortage, editTextShellCoreSandTypeOfSand,
            editTextShellCoreSandSourceOfSand, editTextShellCoreSandLotNumberBatchNumber,
            editTextShellCoreGas, editTextShellCoreCoreCuringTime,
            editTextColdBoxSandTypeOfSand, editTextColdBoxSandSourceOfSand,
            editTextColdBoxSandLotNumberBatchNumber, editTextColdBoxSandTensileStrength,
            editTextColdBoxSandTransverseStrength, editTextColdBoxCoreResinSource,
            editTextColdBoxCoreResinAddition, editTextColdBoxCoreHardenerAddition,
            editTextColdBoxCoreGasingTime, editTextColdBoxCoreNameOfAntiVeining,
            editTextColdBoxCorePercentageOfAntiVeiningAddition, editTextDip1Paint,
            editTextDip2Paint, editTextDip3Paint, editTextDip1Viscosity,
            editTextDip2Viscosity, editTextDip3Viscosity, editTextCoreBoxSetNumberDetails;

    private Button submitButton;
    private ApiService apiService;
    private SessionManager sessionManager;

    private Spinner spinnerOptions;
    private String pouringLine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        spinnerOptions = findViewById(R.id.spinnerOptions);
        editTextMeasurementDate = findViewById(R.id.editTextMeasurementDate);
        editTextMeasurementTime = findViewById(R.id.editTextMeasurementTime);
        editTextPartNumber = findViewById(R.id.editTextPartNumber);
        editTextMakingSubcontractor = findViewById(R.id.editTextMakingSubcontractor);
        editTextMakingDate = findViewById(R.id.editTextMakingDate);
        editTextPaintingSubcontractor = findViewById(R.id.editTextPaintingSubcontractor);
        editTextPaintingDate = findViewById(R.id.editTextPaintingDate);
        editTextNoOfTrays = findViewById(R.id.editTextNoOfTrays);
        editTextNoOfCoresTrays = findViewById(R.id.editTextNoOfCoresTrays);
        editTextTotalCores = findViewById(R.id.editTextTotalCores);
        editTextPatternCavity = findViewById(R.id.editTextPatternCavity);
        editTextNoOfMoldsPoured = findViewById(R.id.editTextNoOfMoldsPoured);
        editTextPouredCores = findViewById(R.id.editTextPouredCores);
        editTextReturnCores = findViewById(R.id.editTextReturnCores);
        editTextMouldingShortage = findViewById(R.id.editTextMouldingShortage);
        editTextShellCoreSandTypeOfSand = findViewById(R.id.editTextShellCoreSandTypeOfSand);
        editTextShellCoreSandSourceOfSand = findViewById(R.id.editTextShellCoreSandSourceOfSand);
        editTextShellCoreSandLotNumberBatchNumber = findViewById(R.id.editTextShellCoreSandLotNumberBatchNumber);
        editTextShellCoreGas = findViewById(R.id.editTextShellCoreGas);
        editTextShellCoreCoreCuringTime = findViewById(R.id.editTextShellCoreCoreCuringTime);
        editTextColdBoxSandTypeOfSand = findViewById(R.id.editTextColdBoxSandTypeOfSand);
        editTextColdBoxSandSourceOfSand = findViewById(R.id.editTextColdBoxSandSourceOfSand);
        editTextColdBoxSandLotNumberBatchNumber = findViewById(R.id.editTextColdBoxSandLotNumberBatchNumber);
        editTextColdBoxSandTensileStrength = findViewById(R.id.editTextColdBoxSandTensileStrength);
        editTextColdBoxSandTransverseStrength = findViewById(R.id.editTextColdBoxSandTransverseStrength);
        editTextColdBoxCoreResinSource = findViewById(R.id.editTextColdBoxCoreResinSource);
        editTextColdBoxCoreResinAddition = findViewById(R.id.editTextColdBoxCoreResinAddition);
        editTextColdBoxCoreHardenerAddition = findViewById(R.id.editTextColdBoxCoreHardenerAddition);
        editTextColdBoxCoreGasingTime = findViewById(R.id.editTextColdBoxCoreGasingTime);
        editTextColdBoxCoreNameOfAntiVeining = findViewById(R.id.editTextColdBoxCoreNameOfAntiVeining);
        editTextColdBoxCorePercentageOfAntiVeiningAddition = findViewById(R.id.editTextColdBoxCorePercentageOfAntiVeiningAddition);
        editTextDip1Paint = findViewById(R.id.editTextDip1Paint);
        editTextDip2Paint = findViewById(R.id.editTextDip2Paint);
        editTextDip3Paint = findViewById(R.id.editTextDip3Paint);
        editTextDip1Viscosity = findViewById(R.id.editTextDip1Viscosity);
        editTextDip2Viscosity = findViewById(R.id.editTextDip2Viscosity);
        editTextDip3Viscosity = findViewById(R.id.editTextDip3Viscosity);
        editTextCoreBoxSetNumberDetails = findViewById(R.id.editTextCoreBoxSetNumberDetails);
        submitButton = findViewById(R.id.submitButton);

        // Initialize SessionManager
        sessionManager = new SessionManager(this);

        // Initialize ApiService using RetrofitClient
        apiService = RetrofitClient.getApiService();

        // Set onClick listener for the submit button
        submitButton.setOnClickListener(v -> submitData());

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOptions.setAdapter(adapter);

        spinnerOptions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                pouringLine = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Optional: handle no selection case if needed
            }
        });

        editTextMeasurementDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        editTextMakingDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        editTextPaintingDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });


        editTextMeasurementTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });
        editTextShellCoreCoreCuringTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });
        editTextColdBoxCoreGasingTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });
        editTextDip1Viscosity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });
        editTextDip2Viscosity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });
        editTextDip3Viscosity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });

    }

    private void submitData() {
        MouldingData dataModel = new MouldingData();
        dataModel.setMeasurementDate(editTextMeasurementDate.getText().toString());
        dataModel.setMeasurementTime(editTextMeasurementTime.getText().toString());
        dataModel.setPartNumber(editTextPartNumber.getText().toString());
        dataModel.setMakingSubcontractor(editTextMakingSubcontractor.getText().toString());
        dataModel.setMakingDate(editTextMakingDate.getText().toString());
        dataModel.setPaintingSubcontractor(editTextPaintingSubcontractor.getText().toString());
        dataModel.setPaintingDate(editTextPaintingDate.getText().toString());
        dataModel.setNoOfTrays(editTextNoOfTrays.getText().toString());
        dataModel.setNoOfCoresTrays(editTextNoOfCoresTrays.getText().toString());
        dataModel.setTotalCores(editTextTotalCores.getText().toString());
        dataModel.setPatternCavity(editTextPatternCavity.getText().toString());
        dataModel.setNoOfMoldsPoured(editTextNoOfMoldsPoured.getText().toString());
        dataModel.setPouredCores(editTextPouredCores.getText().toString());
        dataModel.setReturnCores(editTextReturnCores.getText().toString());
        dataModel.setMouldingShortage(editTextMouldingShortage.getText().toString());
        dataModel.setShellCoreSandTypeOfSand(editTextShellCoreSandTypeOfSand.getText().toString());
        dataModel.setShellCoreSandSourceOfSand(editTextShellCoreSandSourceOfSand.getText().toString());
        dataModel.setShellCoreSandLotNumberBatchNumber(editTextShellCoreSandLotNumberBatchNumber.getText().toString());
        dataModel.setShellCoreGas(editTextShellCoreGas.getText().toString());
        dataModel.setShellCoreCoreCuringTime(editTextShellCoreCoreCuringTime.getText().toString());
        dataModel.setColdBoxSandTypeOfSand(editTextColdBoxSandTypeOfSand.getText().toString());
        dataModel.setColdBoxSandSourceOfSand(editTextColdBoxSandSourceOfSand.getText().toString());
        dataModel.setColdBoxSandLotNumberBatchNumber(editTextColdBoxSandLotNumberBatchNumber.getText().toString());
        dataModel.setColdBoxSandTensileStrength(editTextColdBoxSandTensileStrength.getText().toString());
        dataModel.setColdBoxSandTransverseStrength(editTextColdBoxSandTransverseStrength.getText().toString());
        dataModel.setColdBoxCoreResinSource(editTextColdBoxCoreResinSource.getText().toString());
        dataModel.setColdBoxCoreResinAddition(editTextColdBoxCoreResinAddition.getText().toString());
        dataModel.setColdBoxCoreHardenerAddition(editTextColdBoxCoreHardenerAddition.getText().toString());
        dataModel.setColdBoxCoreGasingTime(editTextColdBoxCoreGasingTime.getText().toString());
        dataModel.setColdBoxCoreNameOfAntiVeining(editTextColdBoxCoreNameOfAntiVeining.getText().toString());
        dataModel.setColdBoxCorePercentageOfAntiVeiningAddition(editTextColdBoxCorePercentageOfAntiVeiningAddition.getText().toString());
        dataModel.setDip1Paint(editTextDip1Paint.getText().toString());
        dataModel.setDip2Paint(editTextDip2Paint.getText().toString());
        dataModel.setDip3Paint(editTextDip3Paint.getText().toString());
        dataModel.setDip1Viscosity(editTextDip1Viscosity.getText().toString());
        dataModel.setDip2Viscosity(editTextDip2Viscosity.getText().toString());
        dataModel.setDip3Viscosity(editTextDip3Viscosity.getText().toString());
        dataModel.setCoreBoxSetNumberDetails(editTextCoreBoxSetNumberDetails.getText().toString());

        dataModel.setPouringLine(pouringLine);

        String token = sessionManager.getToken();

        Call<Void> call = apiService.postMouldingData(dataModel);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(CreateActivity.this, "Data submitted successfully", Toast.LENGTH_SHORT).show();
                    // Reset form or navigate back as needed
                } else {
                    Log.e("SubmitData", "Submission failed: " + response.code() + " " + response.message());

                    try {
                        Log.e("SubmitData", "Error body: " + response.errorBody().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(CreateActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                        editTextMeasurementDate.setText(selectedDate);
                        editTextMakingDate.setText(selectedDate);
                        editTextPaintingDate.setText(selectedDate);

                    }
                }, year, month, day);
        datePickerDialog.show();
    }

    private void showTimePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        String selectedTime = hourOfDay + ":" + minute;
                        editTextMeasurementTime.setText(selectedTime);
                        editTextShellCoreCoreCuringTime.setText(selectedTime);
                        editTextColdBoxCoreGasingTime.setText(selectedTime);
                        editTextDip1Viscosity.setText(selectedTime);
                        editTextDip2Viscosity.setText(selectedTime);
                        editTextDip3Viscosity.setText(selectedTime);
               }
                }, hour, minute, true);
        timePickerDialog.show();
    }
}