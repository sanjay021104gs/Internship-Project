package com.example.loginform;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InspectionActivity extends AppCompatActivity {
    private EditText editTextMeasurementDate, editTextMeasurementTime, editTextDeliveryChallanNo,
            editTextSubContractorName, editTextPartNo, editTextReceivedQuantity,
            editTextInspectionQuantity, editTextRejectionQuantity, editTextProductionDate,
            editTextPaintedDate, editTextTypeOfPaint, editTextVentHole,
            editTextVerificationCoreSticker, editTextVerificationRoofCovering,
            editTextCoreFriability, editTextAirPocket, editTextUnFilling, editTextDepression,
            editTextProjection, editTextDamage, editTextGaugeNotOk, editTextMismatch,
            editTextOthers, editTextShellThicknessSample1, editTextShellThicknessSample2,
            editTextShellThicknessSample3, editTextShellThicknessSample4, editTextShellThicknessSample5,
            editTextScratchHardnessSample1, editTextScratchHardnessSample2, editTextScratchHardnessSample3,
            editTextScratchHardnessSample4, editTextScratchHardnessSample5, editTextShiftOperator,
            editTextShiftSupervisor;

    private Button submitButton;
    private ApiService apiService;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inspection);

        // Initialize EditText fields
        editTextMeasurementDate = findViewById(R.id.editTextMeasurementDate);
        editTextMeasurementTime = findViewById(R.id.editTextMeasurementTime);


        // Initialize the submit button
        submitButton = findViewById(R.id.submitButton);
        sessionManager = new SessionManager(this);

        // Initialize ApiService using RetrofitClient
        apiService = RetrofitClient.getApiService();

        // Set onClick listener for the submit button
        submitButton.setOnClickListener(v -> submitData2());

        // Set DatePicker for Measurement Date
        editTextMeasurementDate.setOnClickListener(v -> showDatePickerDialog(editTextMeasurementDate));

        editTextMeasurementTime.setOnClickListener(v -> showTimePickerDialog(editTextMeasurementTime));
    }

    private void showDatePickerDialog(EditText editText) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String date = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    editText.setText(date);
                }, year, month, day);
        datePickerDialog.show();
    }

    private void showTimePickerDialog(EditText editText) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view, selectedHour, selectedMinute) -> {
                    String time = selectedHour + ":" + selectedMinute;
                    editText.setText(time);
                }, hour, minute, true);
        timePickerDialog.show();
    }

    private void submitData2() {
        // Extract data from EditText fields
        MouldingData2 dataModel2 = new MouldingData2();
        dataModel2.setMeasurementDate(editTextMeasurementDate.getText().toString());
        dataModel2.setMeasurementTime(editTextMeasurementTime.getText().toString());


        // Make API call using Retrofit
        String token = sessionManager.getToken();

        Call<Void> call = apiService.postMouldingData2(dataModel2);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(InspectionActivity.this, "Data submitted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(InspectionActivity.this, "Submission failed: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                if (t instanceof IOException) {
                    Toast.makeText(InspectionActivity.this, "Network Failure", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(InspectionActivity.this, "Conversion Error", Toast.LENGTH_SHORT).show();
                }
                Log.e("API_CALL", "Error: " + t.getMessage());
            }
        });
    }
}
