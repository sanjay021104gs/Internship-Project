package com.example.loginform;

public class MouldingData {
    private String measurementDate;
    private String measurementTime;
    private String partNumber;
    private String pouringLine;
    private String makingSubcontractor;
    private String makingDate;
    private String paintingSubcontractor;
    private String paintingDate;
    private String noOfTrays;
    private String noOfCoresTrays;
    private String totalCores;
    private String patternCavity;
    private String noOfMoldsPoured;
    private String pouredCores;
    private String returnCores;
    private String mouldingShortage;
    private String shellCoreSandTypeOfSand;
    private String shellCoreSandSourceOfSand;
    private String shellCoreSandLotNumberBatchNumber;
    private String shellCoreGas;
    private String shellCoreCoreCuringTime;
    private String coldBoxSandTypeOfSand;
    private String coldBoxSandSourceOfSand;
    private String coldBoxSandLotNumberBatchNumber;
    private String coldBoxSandTensileStrength;
    private String coldBoxSandTransverseStrength;
    private String coldBoxCoreResinSource;
    private String coldBoxCoreResinAddition;
    private String coldBoxCoreHardenerAddition;
    private String coldBoxCoreGasingTime;
    private String coldBoxCoreNameOfAntiVeining;
    private String coldBoxCorePercentageOfAntiVeiningAddition;
    private String dip1Paint;
    private String dip2Paint;
    private String dip3Paint;
    private String dip1Viscosity;
    private String dip2Viscosity;
    private String dip3Viscosity;
    private String coreBoxSetNumberDetails;

    // Getters and setters for each field
    public String getMeasurementDate() {
        return measurementDate;
    }
    public void setMeasurementDate(String measurementDate) {
        this.measurementDate = measurementDate;
    }

    public String getMeasurementTime() {
        return measurementTime;
    }
    public void setMeasurementTime(String measurementTime) {
        this.measurementTime = measurementTime;
    }

    public String getPartNumber() {
        return partNumber;
    }
    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPouringLine() {
        return pouringLine;
    }
    public void setPouringLine(String pouringLine) {
        this.pouringLine = pouringLine;
    }

    public String getMakingSubcontractor() {
        return makingSubcontractor;
    }
    public void setMakingSubcontractor(String makingSubcontractor) {
        this.makingSubcontractor = makingSubcontractor;
    }

    public String getMakingDate() {
        return makingDate;
    }
    public void setMakingDate(String makingDate) {
        this.makingDate = makingDate;
    }

    public String getPaintingSubcontractor() {
        return paintingSubcontractor;
    }
    public void setPaintingSubcontractor(String paintingSubcontractor) {
        this.paintingSubcontractor = paintingSubcontractor;
    }

    public String getPaintingDate() {
        return paintingDate;
    }
    public void setPaintingDate(String paintingDate) {
        this.paintingDate = paintingDate;
    }

    public String getNoOfTrays() {
        return noOfTrays;
    }
    public void setNoOfTrays(String noOfTrays) {
        this.noOfTrays = noOfTrays;
    }

    public String getNoOfCoresTrays() {
        return noOfCoresTrays;
    }
    public void setNoOfCoresTrays(String noOfCoresTrays) {
        this.noOfCoresTrays = noOfCoresTrays;
    }

    public String getTotalCores() {
        return totalCores;
    }
    public void setTotalCores(String totalCores) {
        this.totalCores = totalCores;
    }

    public String getPatternCavity() {
        return patternCavity;
    }
    public void setPatternCavity(String patternCavity) {
        this.patternCavity = patternCavity;
    }

    public String getNoOfMoldsPoured() {
        return noOfMoldsPoured;
    }
    public void setNoOfMoldsPoured(String noOfMoldsPoured) {
        this.noOfMoldsPoured = noOfMoldsPoured;
    }

    public String getPouredCores() {
        return pouredCores;
    }
    public void setPouredCores(String pouredCores) {
        this.pouredCores = pouredCores;
    }

    public String getReturnCores() {
        return returnCores;
    }
    public void setReturnCores(String returnCores) {
        this.returnCores = returnCores;
    }

    public String getMouldingShortage() {
        return mouldingShortage;
    }
    public void setMouldingShortage(String mouldingShortage) {
        this.mouldingShortage = mouldingShortage;
    }

    public String getShellCoreSandTypeOfSand() {
        return shellCoreSandTypeOfSand;
    }
    public void setShellCoreSandTypeOfSand(String shellCoreSandTypeOfSand) {
        this.shellCoreSandTypeOfSand = shellCoreSandTypeOfSand;
    }

    public String getShellCoreSandSourceOfSand() {
        return shellCoreSandSourceOfSand;
    }
    public void setShellCoreSandSourceOfSand(String shellCoreSandSourceOfSand) {
        this.shellCoreSandSourceOfSand = shellCoreSandSourceOfSand;
    }

    public String getShellCoreSandLotNumberBatchNumber() {
        return shellCoreSandLotNumberBatchNumber;
    }
    public void setShellCoreSandLotNumberBatchNumber(String shellCoreSandLotNumberBatchNumber) {
        this.shellCoreSandLotNumberBatchNumber = shellCoreSandLotNumberBatchNumber;
    }

    public String getShellCoreGas() {
        return shellCoreGas;
    }
    public void setShellCoreGas(String shellCoreGas) {
        this.shellCoreGas = shellCoreGas;
    }

    public String getShellCoreCoreCuringTime() {
        return shellCoreCoreCuringTime;
    }
    public void setShellCoreCoreCuringTime(String shellCoreCoreCuringTime) {
        this.shellCoreCoreCuringTime = shellCoreCoreCuringTime;
    }

    public String getColdBoxSandTypeOfSand() {
        return coldBoxSandTypeOfSand;
    }
    public void setColdBoxSandTypeOfSand(String coldBoxSandTypeOfSand) {
        this.coldBoxSandTypeOfSand = coldBoxSandTypeOfSand;
    }

    public String getColdBoxSandSourceOfSand() {
        return coldBoxSandSourceOfSand;
    }
    public void setColdBoxSandSourceOfSand(String coldBoxSandSourceOfSand) {
        this.coldBoxSandSourceOfSand = coldBoxSandSourceOfSand;
    }

    public String getColdBoxSandLotNumberBatchNumber() {
        return coldBoxSandLotNumberBatchNumber;
    }
    public void setColdBoxSandLotNumberBatchNumber(String coldBoxSandLotNumberBatchNumber) {
        this.coldBoxSandLotNumberBatchNumber = coldBoxSandLotNumberBatchNumber;
    }

    public String getColdBoxSandTensileStrength() {
        return coldBoxSandTensileStrength;
    }
    public void setColdBoxSandTensileStrength(String coldBoxSandTensileStrength) {
        this.coldBoxSandTensileStrength = coldBoxSandTensileStrength;
    }

    public String getColdBoxSandTransverseStrength() {
        return coldBoxSandTransverseStrength;
    }
    public void setColdBoxSandTransverseStrength(String coldBoxSandTransverseStrength) {
        this.coldBoxSandTransverseStrength = coldBoxSandTransverseStrength;
    }

    public String getColdBoxCoreResinSource() {
        return coldBoxCoreResinSource;
    }
    public void setColdBoxCoreResinSource(String coldBoxCoreResinSource) {
        this.coldBoxCoreResinSource = coldBoxCoreResinSource;
    }

    public String getColdBoxCoreResinAddition() {
        return coldBoxCoreResinAddition;
    }
    public void setColdBoxCoreResinAddition(String coldBoxCoreResinAddition) {
        this.coldBoxCoreResinAddition = coldBoxCoreResinAddition;
    }

    public String getColdBoxCoreHardenerAddition() {
        return coldBoxCoreHardenerAddition;
    }
    public void setColdBoxCoreHardenerAddition(String coldBoxCoreHardenerAddition) {
        this.coldBoxCoreHardenerAddition = coldBoxCoreHardenerAddition;
    }

    public String getColdBoxCoreGasingTime() {
        return coldBoxCoreGasingTime;
    }
    public void setColdBoxCoreGasingTime(String coldBoxCoreGasingTime) {
        this.coldBoxCoreGasingTime = coldBoxCoreGasingTime;
    }

    public String getColdBoxCoreNameOfAntiVeining() {
        return coldBoxCoreNameOfAntiVeining;
    }
    public void setColdBoxCoreNameOfAntiVeining(String coldBoxCoreNameOfAntiVeining) {
        this.coldBoxCoreNameOfAntiVeining = coldBoxCoreNameOfAntiVeining;
    }

    public String getColdBoxCorePercentageOfAntiVeiningAddition() {
        return coldBoxCorePercentageOfAntiVeiningAddition;
    }
    public void setColdBoxCorePercentageOfAntiVeiningAddition(String coldBoxCorePercentageOfAntiVeiningAddition) {
        this.coldBoxCorePercentageOfAntiVeiningAddition = coldBoxCorePercentageOfAntiVeiningAddition;
    }

    public String getDip1Paint() {
        return dip1Paint;
    }
    public void setDip1Paint(String dip1Paint) {
        this.dip1Paint = dip1Paint;
    }

    public String getDip2Paint() {
        return dip2Paint;
    }
    public void setDip2Paint(String dip2Paint) {
        this.dip2Paint = dip2Paint;
    }

    public String getDip3Paint() {
        return dip3Paint;
    }
    public void setDip3Paint(String dip3Paint) {
        this.dip3Paint = dip3Paint;
    }

    public String getDip1Viscosity() {
        return dip1Viscosity;
    }
    public void setDip1Viscosity(String dip1Viscosity) {
        this.dip1Viscosity = dip1Viscosity;
    }

    public String getDip2Viscosity() {
        return dip2Viscosity;
    }
    public void setDip2Viscosity(String dip2Viscosity) {
        this.dip2Viscosity = dip2Viscosity;
    }

    public String getDip3Viscosity() {
        return dip3Viscosity;
    }
    public void setDip3Viscosity(String dip3Viscosity) {
        this.dip3Viscosity = dip3Viscosity;
    }

    public String getCoreBoxSetNumberDetails() {
        return coreBoxSetNumberDetails;
    }
    public void setCoreBoxSetNumberDetails(String coreBoxSetNumberDetails) {
        this.coreBoxSetNumberDetails = coreBoxSetNumberDetails;
    }
}
