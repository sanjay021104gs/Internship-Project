package com.example.loginform;

public class MouldingData2 {
    private String measurementDate;
    private String measurementTime;
    private String deliveryChallanNo;
    private String subContractorName;
    private String partNumber;
    private int receivedQuantity;
    private int inspectionQuantity;
    private int rejectionQuantity;
    private String productionDate;
    private String paintedDate;
    private String typeOfPaint;
    private String ventHole;
    private String verificationOfCoreIdentificationSticker;
    private String verificationOfRoofCoveringWithTarpaulinOrMetalSheet;
    private String coreFriability;
    private String airPocket;
    private String unFilling;
    private String depression;
    private String projection;
    private String damage;
    private String gaugeNotOk;
    private String mismatch;
    private String others;
    private double shellThicknessSample1;
    private double shellThicknessSample2;
    private double shellThicknessSample3;
    private double shellThicknessSample4;
    private double shellThicknessSample5;
    private int scratchHardnessSample1;
    private int scratchHardnessSample2;
    private int scratchHardnessSample3;
    private int scratchHardnessSample4;
    private int scratchHardnessSample5;
    private String shiftOperator;
    private String shiftSupervisor;

    // Getters and setters for each field

    public String getMeasurementDate() {
        return measurementDate;
    }

    public void setMeasurementDate(String measurementDate) {
        this.measurementDate = measurementDate;
    }

    public String getMeasurementTime() {
        return measurementTime;
    }

    public void setMeasurementTime(String measurementTime) {
        this.measurementTime = measurementTime;
    }

    public String getDeliveryChallanNo() {
        return deliveryChallanNo;
    }

    public void setDeliveryChallanNo(String deliveryChallanNo) {
        this.deliveryChallanNo = deliveryChallanNo;
    }

    public String getSubContractorName() {
        return subContractorName;
    }

    public void setSubContractorName(String subContractorName) {
        this.subContractorName = subContractorName;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public int getReceivedQuantity() {
        return receivedQuantity;
    }

    public void setReceivedQuantity(int receivedQuantity) {
        this.receivedQuantity = receivedQuantity;
    }

    public int getInspectionQuantity() {
        return inspectionQuantity;
    }

    public void setInspectionQuantity(int inspectionQuantity) {
        this.inspectionQuantity = inspectionQuantity;
    }

    public int getRejectionQuantity() {
        return rejectionQuantity;
    }

    public void setRejectionQuantity(int rejectionQuantity) {
        this.rejectionQuantity = rejectionQuantity;
    }

    public String getProductionDate() {
        return productionDate;
    }

    public void setProductionDate(String productionDate) {
        this.productionDate = productionDate;
    }

    public String getPaintedDate() {
        return paintedDate;
    }

    public void setPaintedDate(String paintedDate) {
        this.paintedDate = paintedDate;
    }

    public String getTypeOfPaint() {
        return typeOfPaint;
    }

    public void setTypeOfPaint(String typeOfPaint) {
        this.typeOfPaint = typeOfPaint;
    }

    public String getVentHole() {
        return ventHole;
    }

    public void setVentHole(String ventHole) {
        this.ventHole = ventHole;
    }

    public String getVerificationOfCoreIdentificationSticker() {
        return verificationOfCoreIdentificationSticker;
    }

    public void setVerificationOfCoreIdentificationSticker(String verificationOfCoreIdentificationSticker) {
        this.verificationOfCoreIdentificationSticker = verificationOfCoreIdentificationSticker;
    }

    public String getVerificationOfRoofCoveringWithTarpaulinOrMetalSheet() {
        return verificationOfRoofCoveringWithTarpaulinOrMetalSheet;
    }

    public void setVerificationOfRoofCoveringWithTarpaulinOrMetalSheet(String verificationOfRoofCoveringWithTarpaulinOrMetalSheet) {
        this.verificationOfRoofCoveringWithTarpaulinOrMetalSheet = verificationOfRoofCoveringWithTarpaulinOrMetalSheet;
    }

    public String getCoreFriability() {
        return coreFriability;
    }

    public void setCoreFriability(String coreFriability) {
        this.coreFriability = coreFriability;
    }

    public String getAirPocket() {
        return airPocket;
    }

    public void setAirPocket(String airPocket) {
        this.airPocket = airPocket;
    }

    public String getUnFilling() {
        return unFilling;
    }

    public void setUnFilling(String unFilling) {
        this.unFilling = unFilling;
    }

    public String getDepression() {
        return depression;
    }

    public void setDepression(String depression) {
        this.depression = depression;
    }

    public String getProjection() {
        return projection;
    }

    public void setProjection(String projection) {
        this.projection = projection;
    }

    public String getDamage() {
        return damage;
    }

    public void setDamage(String damage) {
        this.damage = damage;
    }

    public String getGaugeNotOk() {
        return gaugeNotOk;
    }

    public void setGaugeNotOk(String gaugeNotOk) {
        this.gaugeNotOk = gaugeNotOk;
    }

    public String getMismatch() {
        return mismatch;
    }

    public void setMismatch(String mismatch) {
        this.mismatch = mismatch;
    }

    public String getOthers() {
        return others;
    }

    public void setOthers(String others) {
        this.others = others;
    }

    public double getShellThicknessSample1() {
        return shellThicknessSample1;
    }

    public void setShellThicknessSample1(double shellThicknessSample1) {
        this.shellThicknessSample1 = shellThicknessSample1;
    }

    public double getShellThicknessSample2() {
        return shellThicknessSample2;
    }

    public void setShellThicknessSample2(double shellThicknessSample2) {
        this.shellThicknessSample2 = shellThicknessSample2;
    }

    public double getShellThicknessSample3() {
        return shellThicknessSample3;
    }

    public void setShellThicknessSample3(double shellThicknessSample3) {
        this.shellThicknessSample3 = shellThicknessSample3;
    }

    public double getShellThicknessSample4() {
        return shellThicknessSample4;
    }

    public void setShellThicknessSample4(double shellThicknessSample4) {
        this.shellThicknessSample4 = shellThicknessSample4;
    }

    public double getShellThicknessSample5() {
        return shellThicknessSample5;
    }

    public void setShellThicknessSample5(double shellThicknessSample5) {
        this.shellThicknessSample5 = shellThicknessSample5;
    }

    public int getScratchHardnessSample1() {
        return scratchHardnessSample1;
    }

    public void setScratchHardnessSample1(int scratchHardnessSample1) {
        this.scratchHardnessSample1 = scratchHardnessSample1;
    }

    public int getScratchHardnessSample2() {
        return scratchHardnessSample2;
    }

    public void setScratchHardnessSample2(int scratchHardnessSample2) {
        this.scratchHardnessSample2 = scratchHardnessSample2;
    }

    public int getScratchHardnessSample3() {
        return scratchHardnessSample3;
    }

    public void setScratchHardnessSample3(int scratchHardnessSample3) {
        this.scratchHardnessSample3 = scratchHardnessSample3;
    }

    public int getScratchHardnessSample4() {
        return scratchHardnessSample4;
    }

    public void setScratchHardnessSample4(int scratchHardnessSample4) {
        this.scratchHardnessSample4 = scratchHardnessSample4;
    }

    public int getScratchHardnessSample5() {
        return scratchHardnessSample5;
    }

    public void setScratchHardnessSample5(int scratchHardnessSample5) {
        this.scratchHardnessSample5 = scratchHardnessSample5;
    }

    public String getShiftOperator() {
        return shiftOperator;
    }

    public void setShiftOperator(String shiftOperator) {
        this.shiftOperator = shiftOperator;
    }

    public String getShiftSupervisor() {
        return shiftSupervisor;
    }

    public void setShiftSupervisor(String shiftSupervisor) {
        this.shiftSupervisor = shiftSupervisor;
    }
}
